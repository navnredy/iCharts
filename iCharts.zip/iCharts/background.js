chrome.runtime.onInstalled.addListener(() => {
    console.log("Service worker installed.");
});