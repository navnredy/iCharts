let data = null;
let observer = null;
let intervalValue = 0;
let options = {
    "canShowAlerts": true
};

function reset() {
    data = {
        'highestCEOI': 0,
        'highestCEConfirmedTime':0,
        'highestPEOI': 0,
        'highestPEConfirmedTime':0,
        'lastRecordTime':"00:00",
        'isCESideTriggered': false,
        'isPESideTriggered': false,
        'peTrend': '',
        'ceTrend': '',
        'ceOrders': {
            'SELL': '',
            'BUY': ''
        },
        'peOrders': {
            'SELL': '',
            'BUY': ''
        },
        'ceTelMessageId': '',
        'peTelMessageId': ''
    };

    options.canShowAlerts = true;
}

function createElement(tagName, options) {
    let elem = document.createElement(tagName);

    if(options.className)
        elem.className = options.className;
    if(options.attributes) {
        for (const key in options.attributes) {
            let ariaAtomicAttr = document.createAttribute(key);
            ariaAtomicAttr.value = options.attributes[key];
            elem.attributes.setNamedItem(ariaAtomicAttr);
        }
    }
    if(options.text) {
        elem.innerHTML = options.text;
    }
    if(options.id){
        elem.id = options.id;
    }

    if(options.events) {
        for (const key in options.events) {
            elem.addEventListener(key, options.events[key]);
        }
    }

    return elem;
}

function addAlertAudio() {
    let mp3 = chrome.runtime.getURL('alert.mp3');
    let audio = createElement('audio', {
        'attributes': {
            'src': mp3,
            'controls': true,
            'muted': true
        },
        'id': 'alert-audio'
    });
    audio.addEventListener('ended', () => {
        audio.currentTime = 0;
        audio.play();
    });
    document.body.appendChild(audio);
}

function playSound() {
    let audio = document.getElementById("alert-audio");
    audio.muted= false;
    audio.play();
}

function stopSound() {
    let audio = document.getElementById("alert-audio");
    audio.muted= true;
    audio.pause();
}

function createAlert(id, className, message, canShow) {
    let container = createElement("div", {
        className: 'alert alert-danger alert-dismissible shadow-sm z-index-fix position-absolute m-2 invisible '+ className,
        id: id,
        text: "<strong>Alert</strong>",
        attributes: {role: 'alert'}
    });
    document.body.appendChild(container);

    let messageBody = createElement("div", {
        id: 'message-body',
        text: message || ''
    });
    container.appendChild(messageBody);

    if(canShow) {
        container.classList.remove('invisible');
        container.classList.add("show");
    }

    let button = createElement("button", {
        className: 'btn-close',
        id: 'alert-container',
        attributes: {role: 'alert', type:'button', 'data-bs-dismiss':'alert', 'aria-label': 'Close'},
        events: {
            'click': () => {
                container.classList.remove('show');
                container.classList.add("invisible");
                if(canShow) {
                    stopSound();
                    options["canShowAlerts"] = true;
                }
            }
        }
    });
    container.appendChild(button);
}

async function sendTelMessage(isCESignal, canEnter, rowTime, trend, strikes) {

    if(!options["canShowAlerts"] || !isLatestChart())
        return;

    let url = "https://api.telegram.org/bot6227947912:AAEt-P0Y6F4w22ZF4GDklNrHs23uUHlZwwQ/sendMessage";
    let text = "Please exit your positions.";
    let entities = [
        {
            "offset": 0,
            "length": 27,
            "type": "bold"
        }
    ];
    if(canEnter) {

        text = "Alert\n\n";
        text += "Time: " + rowTime + "\n";
        text += "Trend: " + trend + "\n\n";
        text += "* Place Sell Order: " + strikes["SELL"] + "\n";
        text += "* Place Buy Order: " + strikes["BUY"] + "\n";

        entities = [
            {
                "offset": 0,
                "length": 5,
                "type": "bold"
            },
            {
                "offset": 13,
                "length": 5,
                "type": "bold"
            },
            {
                "offset": 26,
                "length": 6,
                "type": "bold"
            },
            {
                "offset": 54,
                "length": 23,
                "type": "bold"
            },
            {
                "offset": 97,
                "length": 23,
                "type": "bold"
            }
        ];
        if (trend === "Weak") {
            entities = [
                {
                    "offset": 0,
                    "length": 5,
                    "type": "bold"
                },
                {
                    "offset": 13,
                    "length": 5,
                    "type": "bold"
                },
                {
                    "offset": 26,
                    "length": 4,
                    "type": "bold"
                },
                {
                    "offset": 52,
                    "length": 23,
                    "type": "bold"
                },
                {
                    "offset": 95,
                    "length": 23,
                    "type": "bold"
                }
            ];
        }
    }

    let data = {
        "chat_id": -1001966506026,
        "text": text,
        "entities": entities
    }

    if(!canEnter) {
        data["reply_to_message_id"] = isCESignal ? options["ceTelMessageId"] : options["peTelMessageId"];
    }

    let response = await fetch(url, {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/json'
                                                    },
                                                    body: JSON.stringify(data)
                                                });
    let responseData = response.json();
    if(canEnter) {
        let messageId = responseData?.result['message_id'];
        if (isCESignal) {
            options['ceTelMessageId'] = messageId;
        } else {
            options['peTelMessageId'] = messageId;
        }
    } else {
        options['ceTelMessageId'] = '';
        options['peTelMessageId'] = '';
    }

}

function showAlertAndNotification( messageData, isCE ) {

    if(!options["canShowAlerts"] || !isLatestChart())
        return;

    let alertContainer = document.querySelector(isCE? "#alert-ce-id": "#alert-pe-id");
    let messageBody = alertContainer.querySelector("#message-body");

    messageBody.innerHTML = messageData["message"];
    if(messageData["isEntry"]) {
        alertContainer.classList.remove("alert-danger");
        alertContainer.classList.add("alert-success");
    } else {
        alertContainer.classList.remove("alert-success");
        alertContainer.classList.add("alert-danger");
    }
    alertContainer.classList.remove("invisible");
    alertContainer.classList.add("show");

    try{
        playSound();
    } catch(error) {
        console.log("Please click on the page to get Alerts")
    }

    setTimeout(() => {
        alertContainer.classList.remove('show');
        alertContainer.classList.add("invisible");
        stopSound();
    }, 10*1000)

}
function prepareEnterMessage(time, trend, strike, isEntry) {
    let messageOptions = {
        "trend":trend,
        "isEntry": isEntry
    };
    let message = "<br/>Place Sell Order : <strong>"+strike["SELL"]+"</strong>";
    message += "<br/><br/>Place Buy Order : <strong>"+strike["BUY"]+"</strong>";
    message += "<br/><br/>Trend : <strong>"+trend+"</strong>"
    messageOptions.message = message;
    return messageOptions;
}

function prepareExitMessage(time, isCEExit) {
    let messageOptions = {
        "isEntry": false
    };
    let placedOrders = isCEExit ? data["ceOrders"] : data["peOrders"];
    let message = "<br/>Exit from <strong>"+ placedOrders['SELL']+"</strong>";
    message += "<br/><br/>Exit from <strong>"+ placedOrders['BUY']+"</strong>";
    messageOptions.message = message;
    return messageOptions;
}

function getTrend(high, current) {
    let trend = (((high-current)/high)*100).toFixed(2);
    if( trend < 2 ) {
        return "Weak";
    } else if(trend < 4.99) {
        return "Normal";
    } else {
        return "Strong"
    }
}

function getStrikePrice(futureValue, isCESignal ) {
    const bnPrice = futureValue;
    const remainder = bnPrice % 100;
    let strikePrice = (bnPrice - remainder) + (remainder >= 50 ? 100: 0);
    let symbolAndExpiry = getSymbolAndExpiry();
    let returnStrikes = {};
    if(isCESignal) {
        returnStrikes["SELL"] = symbolAndExpiry+ (strikePrice - 300)+"PE";
        returnStrikes["BUY"] = symbolAndExpiry + (strikePrice - 200)+"CE";
    } else {
        returnStrikes["SELL"] = symbolAndExpiry + (strikePrice + 300)+"CE";
        returnStrikes["BUY"] = symbolAndExpiry+ (strikePrice + 200)+"PE";
    }
    return returnStrikes;
}

function getTimeStampFromStr(time) {
    try{
        let [hours, minutes] = time.split(":").map(Number);
        let currentDate = new Date();

        // Set the hours and minutes in the currentDate object
        currentDate.setHours(hours);
        currentDate.setMinutes(minutes);
        currentDate.setSeconds(59);

        let timestamp = currentDate.getTime();

        return timestamp;
    } catch (error) {
        console.log('Error on function *getTimeStampFromStr* for ', time);
    }

}

function isLatestChart() {
    let chartDateStr = document.querySelectorAll(".right_side")[1].querySelectorAll("span")[7].innerText.trim();
    const matchResult = chartDateStr.match(/(\d{2}-[A-Za-z]{3}-\d{4})/);
    let chartDate = matchResult ? matchResult[1] : null;

    const currentDate = new Date();
    const day = currentDate.getDate().toString().padStart(2, '0');
    const month = currentDate.toLocaleString('default', { month: 'short' });
    const year = currentDate.getFullYear();
    let formattedDate =  `${day}-${month}-${year}`;

    if (chartDate === formattedDate) {
        return true;
    }
    return false;
}

function getSymbolAndExpiry() {
    let symbolField = document.querySelector("#optSymbol");
    let expiryField = document.querySelector("#optExpDate");
    if(!expiryField)
        expiryField = document.querySelector("#optExpDate_hist");

    let expiry = expiryField.value.trim();
    const dateRegex = /^(\d{2})([A-Z]{3})(\d{2})$/;
    const match = expiry.match(dateRegex);

    const day = match[1];
    const month = match[2];
    const year = match[3];

    return symbolField.value.trim()+year+month+day;
}

function getListener() {
    if (observer)
        observer.disconnect();
    reset();
    setTimeout(initiateChecker, 1000);
}

window.addEventListener ("load", ()=>{

    reset();
    addAlertAudio();
    createAlert('sound-active-id', 'alert-box-sound-position', '<br/>Please close this alert to activate sound', true);
    createAlert('alert-ce-id', 'alert-box-ce-position');
    createAlert('alert-pe-id', 'alert-box-pe-position');

    let optSymbol = document.querySelector("#optSymbol");
    if(optSymbol.value !== 'BANKNIFTY') {
        for (let i = 0; i < optSymbol.options.length; i++) {
            if (optSymbol.options[i].value === 'BANKNIFTY') {
                optSymbol.selectedIndex = i;
                break;
            }
        }
    }

    // Get the time interval
    let intervalField = document.querySelector('#interval');
    intervalField.addEventListener('change', getListener);

    // Get the date and listen the change events
    let dateField = document.querySelector('#txtDate');
    if(dateField) {
        dateField.addEventListener('change', getListener);
    }

    // Get the Expiry date and listen the changes
    let expiryField = document.querySelector('#optExpDate');
    if(expiryField)
        expiryField.addEventListener('change', getListener);

    // Get the Expiry date history and listen the changes
    let expiryFieldHist = document.querySelector('#optExpDate_hist');
    if(expiryFieldHist)
        expiryFieldHist.addEventListener('change', getListener);

    initiateChecker();
}, false);



function initiateChecker() {

    console.clear();

    // Get the table element
    const table = document.getElementById("sort_table");
    const tbody = table.querySelector("tbody");
    // Check if the <tbody> element is available
    if (tbody) {
        // Read existing rows and get the highest OI
        const rows = tbody.querySelectorAll('tr');
        for (let i = rows.length-1; i > 0 ; i--) {
            options["canShowAlerts"] = false;
            checkOIChanges(rows[i]);
        }
        options["canShowAlerts"] = true;
        options["extractedExitingRecords"] = true;
        // If <tbody> is available, set up the MutationObserver
        observer = new MutationObserver(handleNewRowAdded);
        const observerOptions = {
            childList: true
        };
        observer.observe(tbody, observerOptions);
    } else {
        // If <tbody> is not available, check again after a short delay
        setTimeout(initiateChecker, 1000);
    }
}

function handleNewRowAdded(mutationsList, observer) {
    mutationsList.forEach((mutation) => {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
            for (let i = mutation.addedNodes.length-1; i > 0 ; i--) {
                let currentRow = mutation.addedNodes[i];
                let childNodes = currentRow.children;
                let rowTime = childNodes[0].innerText.trim();
                if(getTimeStampFromStr(data['lastRecordTime']) < getTimeStampFromStr(rowTime))
                    checkOIChanges(currentRow);
            }
        }
    });
}

function exitOrders(isCESignal, rowTime) {
    sendTelMessage(isCESignal, false, rowTime);
    showAlertAndNotification(prepareExitMessage(rowTime, isCESignal), isCESignal);
    if(isCESignal) {
        console.log('Exit confirmation on CE side @', rowTime);
        data["isCESideTriggered"] = false;
        data['ceOrders'] = {};
    } else {
        console.log('Exit confirmation on PE side @', rowTime);
        data["isPESideTriggered"] = false;
        data['peOrders'] = {};
    }
}

function enterOrders(isCESignal, rowTime, highestOI, rowOI, futureValue) {
    let trend = getTrend(highestOI, rowOI);
    let strikePrice = getStrikePrice(futureValue, isCESignal);
    sendTelMessage(isCESignal, true, rowTime, trend, strikePrice );
    showAlertAndNotification(
        prepareEnterMessage(rowTime, trend, strikePrice, true),
        isCESignal
    );
    if(isCESignal) {
        console.log('Signal confirmation on CE side @', rowTime, 'Trend:', trend, 'Strike Price:', strikePrice);
        data["ceOrders"] = strikePrice;
        data["highestCEConfirmedTime"] = rowTime;
        data["isCESideTriggered"] = true;
        data["ceTrend"] = trend;

        if(data["isPESideTriggered"]) {
            //exitOrders(false, rowTime);
        }
    } else {
        console.log('Signal confirmation on PE side @', rowTime, 'Trend:', trend,'Strike Price:', strikePrice);
        data["peOrders"] = strikePrice;
        data["highestPEConfirmedTime"] = rowTime;
        data["isPESideTriggered"] = true;
        data["peTrend"] = trend;

        if (data["isCESideTriggered"]) {
            //exitOrders(true, rowTime);
        }
    }
}

function checkOIChanges(row) {
    let childNodes = row.children;
    let rowTime = childNodes[0].innerText.trim();
    if(getTimeStampFromStr(rowTime) > getTimeStampFromStr(data["lastRecordTime"])) {

        let futureValue = parseInt(childNodes[1].innerText.trim().replace(/,/g, ''));
        //console.log('Checking OI', rowTime)

        let rowCE = parseInt(childNodes[9].innerText.trim().replace(/,/g, ''));
        let rowPE = parseInt(childNodes[10].innerText.trim().replace(/,/g, ''));

        let currentHighestCEOI = data["highestCEOI"];
        if (rowCE > currentHighestCEOI ) {
            data["highestCEOI"] = rowCE;
            if (data["isCESideTriggered"]) {
                exitOrders(true, rowTime);
            }
        } else if (!data["isCESideTriggered"]) {
            enterOrders(true, rowTime, currentHighestCEOI, rowCE, futureValue);
        }
        let currentHighestPEOI = data["highestPEOI"];
        if (rowPE > currentHighestPEOI) {
            data["highestPEOI"] = rowPE;
            if (data["isPESideTriggered"]) {
                exitOrders(false, rowTime);
            }
        } else if (!data["isPESideTriggered"]) {
            enterOrders(false, rowTime, currentHighestPEOI, rowPE, futureValue);
        }
        data['lastRecordTime'] = rowTime;
    }
}

