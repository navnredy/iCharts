$(function (){
    let hideClosedOrders = document.getElementById('hideClosed');

    let options = {};

    hideClosedOrders.addEventListener('change', function() {
        options["canHide"] = !options["canHide"];
        let queryOptions = { active: true, currentWindow: true };
        sendMessageToContentJS({canHide: options["canHide"]});
    });

    sendMessageToContentJS = function (message) {
        let queryOptions = { active: true, currentWindow: true };
        chrome.tabs.query(queryOptions).then(result => {
            chrome.tabs.sendMessage(result[0].id, message);
        });
    }
});
